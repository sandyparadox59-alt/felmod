<?php

namespace Pterodactyl\Console\Commands;

use Illuminate\Console\Command;
use Pterodactyl\Models\User;
use Carbon\Carbon;
use Pterodactyl\Services\Servers\ServerDeletionService;

class DeleteExpiredUsers extends Command
{
    protected $signature = 'users:delete-expired';
    protected $description = 'Delete users and their servers when expired.';

    public function handle(ServerDeletionService $deleter)
    {
        $expiredUsers = User::where('is_permanent', false)
            ->whereNotNull('expires_at')
            ->where('expires_at', '<', Carbon::now())
            ->where('id', '!=', 1) // <- Jangan hapus admin utama
            ->get();

        foreach ($expiredUsers as $user) {

            // Hapus server milik user
            foreach ($user->servers as $server) {
                $deleter->handle($server);
            }

            // Hapus user
            $user->delete();

            $this->info("Deleted expired user: {$user->username} (ID: {$user->id})");
        }

        $this->info('Expired users deletion completed.');
        return 0;
    }
}