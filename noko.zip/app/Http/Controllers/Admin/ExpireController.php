<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\User;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Pterodactyl\Services\Servers\SuspensionService;

class ExpireController extends Controller
{
    private $suspensionService;

    public function __construct(SuspensionService $suspensionService)
    {
        $this->suspensionService = $suspensionService;
    }

    public function index()
    {
        $users = User::query()
            ->orderBy('is_permanent', 'desc')
            ->orderBy('expires_at', 'asc')
            ->paginate(20);

        return view('admin.expire.index', [
            'users' => $users,
        ]);
    }

    public function updateUser(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $request->validate([
            'expires_at' => 'nullable|date',
            'is_permanent' => 'boolean',
        ]);

        $data = $request->only(['is_permanent']);
        
        // Handle expires_at
        if ($request->is_permanent) {
            $data['expires_at'] = null;
        } else {
            $data['expires_at'] = $request->expires_at 
                ? Carbon::parse($request->expires_at)
                : null;
        }

        $user->update($data);

        // Auto-suspend jika kurang dari 2 jam
        if (!$user->is_permanent && $user->expires_at && $user->expires_at->diffInHours(now()) <= 2) {
            foreach ($user->servers as $server) {
                if (!$server->isSuspended()) {
                    $this->suspensionService->toggle($server, 'suspend');
                }
            }
        }

        return back()->with('success', "User {$user->username} has been updated successfully!");
    }
}