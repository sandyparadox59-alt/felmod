<?php

namespace Pterodactyl\Console\Commands\User;

use Illuminate\Console\Command;
use Pterodactyl\Models\User;
use Carbon\Carbon;
use Pterodactyl\Services\Servers\SuspensionService;
use Illuminate\Support\Facades\Redis;

class AutoSuspendExpiringUsers extends Command
{
    protected $signature = 'users:auto-suspend';
    protected $description = 'Auto-suspend servers and set notifications for users expiring within 2 hours';

    public function handle(SuspensionService $suspensionService)
    {
        $now = Carbon::now();
        $threshold = $now->addHours(2);
        
        // Reset threshold untuk query
        $threshold = Carbon::now()->addHours(2);
        
        $expiringUsers = User::where('is_permanent', false)
            ->where('id', '!=', 1)
            ->whereNotNull('expires_at')
            ->where('expires_at', '>', Carbon::now()) // Not expired yet
            ->where('expires_at', '<=', $threshold) // Within 2 hours
            ->with('servers')
            ->get();

        $suspendedCount = 0;
        $notifiedCount = 0;
        
        foreach ($expiringUsers as $user) {
            // Auto-suspend semua server
            foreach ($user->servers as $server) {
                if (!$server->isSuspended()) {
                    try {
                        $suspensionService->toggle($server, 'suspend');
                        $suspendedCount++;
                        $this->info("Auto-suspended server: {$server->name} for {$user->username}");
                    } catch (\Exception $e) {
                        $this->error("Failed to suspend server: " . $e->getMessage());
                    }
                }
            }
            
            // Set Redis notification untuk user
            try {
                $minutesLeft = $user->expires_at->diffInMinutes(Carbon::now());
                $notificationData = [
                    'type' => 'expiring_soon',
                    'message' => "Your account will expire in {$minutesLeft} minutes!",
                    'expires_at' => $user->expires_at->toISOString(),
                    'minutes_left' => $minutesLeft,
                    'show_countdown' => true,
                    'auto_close' => 5, // detik
                    'show_close_button' => true
                ];
                
                // Simpan notifikasi di Redis untuk diakses oleh user
                Redis::setex("user_notification:{$user->id}", 7200, json_encode($notificationData));
                $notifiedCount++;
                
                $this->info("Set notification for user: {$user->username} ({$minutesLeft} minutes left)");
                
            } catch (\Exception $e) {
                $this->error("Failed to set notification for {$user->username}: " . $e->getMessage());
            }
        }

        if ($suspendedCount > 0 || $notifiedCount > 0) {
            $this->info("\n✅ Auto-suspend completed!");
            $this->info("   Servers suspended: {$suspendedCount}");
            $this->info("   Users notified: {$notifiedCount}");
        } else {
            $this->info("\nℹ️ No users expiring within 2 hours.");
        }

        return 0;
    }
}